# Run 1 3DS — original map geometry correction (V0.5)

The earlier native port had the actual Flash map hex strings but incorrectly mapped the four nibbles to floor/walls. This made the 3DS level layouts differ substantially from your original gameplay video. The native geometry now follows the source SWF's actual six-by-six tunnel parser (method 11): each encoded row holds RIGHT / FLOOR / LEFT / CEILING in that order, with bit 0 at the start of each edge. Previously, 0x0F00 (solid floor) became a left wall. The corrected decoder is validated against an independent 6x6 grid reconstruction for every cell of every 50-level map.

The renderer now connects adjacent tile edges without artificial black gaps. Neither original level strings nor original SWF graphics have been changed. Your supplied HOME Menu icon/banner and existing SWF alien animations remain.

## Apply to an existing V0.3 build without losing bannertool/makerom

1. Put `Run1_3DS_V05_MAP_FIX_OVERLAY.zip` in your Windows Downloads directory.
2. Open devkitPro MSYS2 and run:

```bash
cd /c/Users/natha/Downloads
unzip -o Run1_3DS_V05_MAP_FIX_OVERLAY.zip
cd Run1_Original_Maps_3DS_CIA_V03_OG_Alien
make clean
bash BUILD_CIA_MSYS2.sh
```

The corrected CIA is named `Run1_2008_3DS_V05_MAP_FIXED.cia`. The build script will use the tools you have already installed in this same V0.3 folder. The source ZIP does not include the Windows `bannertool.exe` or `makerom.exe`, but your current folder retains them.

**Still incomplete:** Flash-exact camera perspective, level entry/exit positions, physics, Infinite Mode, original menu and music are separate tasks. The map data and wall orientation are now verified against the uploaded SWF, but the full game is not 1:1 or hardware-tested here.
