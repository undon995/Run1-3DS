# Run 1 3DS V0.6 — SWF original title menu

This update uses the original Flash `run.` logo, starfield, menu-choice text, selection circles, Normal/Fast text, checkmark, and `credits.` vector artwork extracted from the user-supplied `Run.swf`. **No AI-generated replacement art.** It also retains the V0.5 corrected 50-map decoder and the original alien sprite frames.

## Title screen

Top screen: original assets for the Run title, Adventure / Infinite / Edit / Credits, and game-speed Normal/Fast choices. A small added selector indicates which menu option is focused. Bottom screen: clickable menu, speed toggle, Level Select shortcut, and Exit button.

Controls: D-pad Up/Down to select; **A** to activate; **X** toggles Normal/Fast; **Y** opens level selection; **START** exits from the title; touchscreen also works. Only Adventure and Credits are actionable from the original four modes. Infinite Mode and Edit Mode are displayed faithfully but do not launch yet. The native Fast setting uses an approximate 1.35× simulation multiplier; this is **not** yet confirmed to match Flash physics precisely.

## Apply as an overlay over working V0.3/V0.5

Download `Run1_3DS_V06_TITLE_OVERLAY.zip` to Windows Downloads and, in devkitPro MSYS2, run:

```bash
cd /c/Users/natha/Downloads
unzip -o Run1_3DS_V06_TITLE_OVERLAY.zip
cd Run1_Original_Maps_3DS_CIA_V03_OG_Alien
make clean
bash BUILD_CIA_MSYS2.sh
```

Your existing `bannertool.exe` and `makerom.exe` remain in the old folder. Output: `Run1_2008_3DS_V06_OG_TITLE.cia` if build succeeds.

The image assets are sourced from the SWF already provided in this conversation and meant for personal testing. The menu layout is adapted to the 400×240 3DS top display; it is **not pixel-for-pixel identical** to the original 550×400 Flash window. Original soundtrack and exact Flash physics are not yet wired into this build.

Not compiled or run on actual 3DS hardware in this environment. Existing game-logic tests and source checks are run locally.
