#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export DEVKITPRO="${DEVKITPRO:-/opt/devkitpro}"
export DEVKITARM="${DEVKITARM:-$DEVKITPRO/devkitARM}"
if [[ ! -f "$DEVKITARM/3ds_rules" ]]; then
  echo 'ERROR: Run inside devkitPro MSYS2 (devkitARM not found).'; exit 1
fi
# Locate packaging tools locally, otherwise retrieve Windows releases.
find_or_install() {
  local name="$1" url="$2" item="$3"
  if [[ -s "tools/$name.exe" ]]; then echo "$PWD/tools/$name.exe"; return; fi
  if [[ -s "$name.exe" ]]; then echo "$PWD/$name.exe"; return; fi
  mkdir -p tools
  echo "[tools] Downloading $name..." >&2
  curl -fL --retry 2 "$url" -o "tools/${name}_download.zip" >&2
  unzip -jo -o "tools/${name}_download.zip" "$item" -d tools >&2
  [[ -s "tools/$name.exe" ]] || { echo "ERROR: $name failed" >&2; return 1; }
  echo "$PWD/tools/$name.exe"
}
BANNERTOOL="$(find_or_install bannertool https://github.com/Epicpkmn11/bannertool/releases/download/v1.2.2/bannertool.zip windows-x86_64/bannertool.exe)"
MAKEROM="$(find_or_install makerom https://github.com/3DSGuy/Project_CTR/releases/download/makerom-v0.19.0/makerom-v0.19.0-win_x86_64.zip makerom.exe)"
TEX3DS="$DEVKITPRO/tools/bin/tex3ds.exe"
if [[ ! -f "$TEX3DS" ]]; then
    TEX3DS="$(command -v tex3ds.exe || command -v tex3ds || true)"
fi
[[ -n "$TEX3DS" && -f "$TEX3DS" ]] || { echo 'ERROR: devkitPro tex3ds not found.'; exit 1; }

echo '[1/5] Checking original Flash game assets...'
[[ -s run_sprites.t3s ]] || { echo 'ERROR: run_sprites.t3s is missing from ZIP.'; exit 1; }
count=0
while IFS= read -r sprite || [[ -n "$sprite" ]]; do
  sprite="${sprite%$'\r'}"
  [[ -z "$sprite" || "$sprite" == \#* ]] && continue
  [[ -s "$sprite" ]] || { echo "ERROR: Missing original asset: $sprite"; exit 1; }
  count=$((count+1))
done < run_sprites.t3s
[[ $count -eq 46 ]] || { echo "ERROR: expected 46 images, found $count"; exit 1; }
[[ -s assets/original_run_music_22050_mono_s16le.pcm ]] || { echo 'ERROR: Original music missing'; exit 1; }
[[ -s source/run_music_data.s ]] || { echo 'ERROR: music assembly data missing'; exit 1; }
[[ ! -e source/run_music.s ]] || { echo 'ERROR: old run_music.s conflicts with run_music.c'; exit 1; }
echo '[2/5] Converting original Run SWF graphics...'
rm -f assets/run_sprites.t3x
"$TEX3DS" --atlas -f rgba4 -z none -i run_sprites.t3s -o assets/run_sprites.t3x
[[ -s assets/run_sprites.t3x ]] || { echo 'ERROR: texture atlas conversion failed'; exit 1; }

echo '[3/5] Compiling Run1_2008_3DS.3dsx and ELF...'
make clean
make -j2
[[ -s Run1_2008_3DS.3dsx && -s Run1_2008_3DS.elf ]] || { echo 'ERROR: .3dsx or .elf not built'; exit 1; }
mkdir -p OUTPUT cia_build
cp -f Run1_2008_3DS.3dsx OUTPUT/Run1_2008_3DS.3dsx

echo '[4/5] Creating original HOME Menu icon and banner...'
"$BANNERTOOL" makesmdh -s 'Run 1 3DS' -l 'Run Classic' -p 'Homebrew Port' -i assets/icon.png -o cia_build/icon.icn
"$BANNERTOOL" makebanner -i assets/banner.png -a assets/banner.wav -o cia_build/banner.bnr
[[ -s cia_build/icon.icn && -s cia_build/banner.bnr ]] || { echo 'ERROR: icon/banner build failed'; exit 1; }

echo '[5/5] Packaging CIA with different Title ID (uncompressed music)...'
grep -Eq '^[[:space:]]*UniqueId:[[:space:]]*0xFF7A6([[:space:]]|$)' project.rsf || { echo 'ERROR: Run Title ID missing'; exit 1; }
# Save complete makerom log in case the last stage fails.
"$MAKEROM" -v -f cia -o OUTPUT/Run1_2008_3DS_MUSIC.cia -target t -exefslogo -rsf project.rsf -elf Run1_2008_3DS.elf -icon cia_build/icon.icn -banner cia_build/banner.bnr 2>&1 | tee cia_build/makerom.log
[[ -s OUTPUT/Run1_2008_3DS_MUSIC.cia ]] || { echo 'ERROR: CIA missing; inspect cia_build/makerom.log'; exit 1; }
cp -f OUTPUT/Run1_2008_3DS_MUSIC.cia .
echo
echo 'BUILD SUCCESS! BOTH FILES ARE IN THE OUTPUT FOLDER:'
ls -lh OUTPUT/Run1_2008_3DS.3dsx OUTPUT/Run1_2008_3DS_MUSIC.cia
