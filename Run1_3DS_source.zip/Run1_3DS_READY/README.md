# Run 1 3DS V0.9 — Music On/Off settings

This version brings together the **separate Run 1 CIA Title ID** (`UniqueId: 0xFF7A6`), **real Run.swf soundtrack** extracted from the SWF you supplied, **Music On/Off setting**, 50 original Adventure map layouts, original alien artwork, original Flash title screen and your chosen 3DS banner/icon.

## Build on Windows (devkitPro MSYS2)

1. Download `Run1_3DS_V09_Music_Settings_FULL.zip` into Windows Downloads.
2. Open devkitPro MSYS2 and paste:

```bash
cd /c/Users/natha/Downloads
unzip -o Run1_3DS_V09_Music_Settings_FULL.zip
cd Run1_3DS_V09_MUSIC_SETTINGS
bash BUILD_CIA_MSYS2.sh
```

The output, **if compilation succeeds**, is `Run1_2008_3DS_V09_MUSIC_SETTINGS.cia`.

`bannertool.exe` and `makerom.exe` are not included in this ZIP. The script checks your previous `Run1_Original_Maps_3DS_CIA_V03_OG_Alien` folder automatically, or you can copy both `.exe` files into this folder.

## How to change the music

- On the original-style title screen, tap **SETTINGS** at the bottom, or press **R**.
- On the Settings screen, tap **MUSIC: ON/OFF** or press **A**. Press **B** or tap **BACK** to return.
- While paused, press **X** or tap the Music button to toggle.
- During gameplay, **X** also toggles music quickly.
- Music is **ON by default**, unless you saved it OFF.
- The preference is stored in `sdmc:/3ds/Run1_2008_3DS/settings.dat` and restored next launch. It does not change the older `save.dat` Adventure progress file.

The Settings screen shows a save error if the SD card cannot be written. If the emulator's DSP service does not work, the menu may show `MUSIC DSP UNAVAILABLE` even while preference is ON.

## Installing and testing

Azahar: **File → Install CIA** → choose `Run1_2008_3DS_V09_MUSIC_SETTINGS.cia` → run the game. It should **install independently of Impossible Game**. If an older Run CIA already replaced Impossible Game in Azahar, reinstall the Impossible Game CIA separately.

## Scope and verification

- Genuine Run.swf audio track (DefineSound 643), streamed from ROM using a 32 KiB linear-RAM buffer; music streaming is muted/unmuted without restarting the game.
- Genuine Flash character and menu artwork; original 50 Adventure level data and wall decoder retained.
- The audio/video timing, collision, camera, Infinite and Edit modes, and traffic-light visuals are not yet exact. This remains a native reconstruction, not the original Flash executable running on 3DS.
- Native CIA compilation and Azahar runtime **cannot be verified in this environment**. Host-side tests validate level decoding, save compatibility and music preference persistence, plus syntax checks on the changed files.
- Music from your SWF is included for **private testing** only, not a grant of public redistribution rights.
