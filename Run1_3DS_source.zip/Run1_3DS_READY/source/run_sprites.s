    .section .rodata
    .balign 16
    .global run_sprites_t3x_start
run_sprites_t3x_start:
    .incbin "../assets/run_sprites.t3x"
    .global run_sprites_t3x_end
run_sprites_t3x_end:
    .balign 4
