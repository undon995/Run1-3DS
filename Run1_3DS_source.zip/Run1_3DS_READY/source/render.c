#include <citro2d.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include "game.h"
#include "run_music.h"
#include "original_maps.h"

/* GPU atlas compiled from genuine vector and bitmap resources in Run.swf. */
extern const unsigned char run_sprites_t3x_start[];
extern const unsigned char run_sprites_t3x_end[];
static C2D_SpriteSheet original_sheet = NULL;

void run_graphics_init(void) {
    size_t blob_size = (size_t)(run_sprites_t3x_end - run_sprites_t3x_start);
    if (blob_size > 32 && blob_size < 8u * 1024u * 1024u)
        original_sheet = C2D_SpriteSheetLoadFromMem(run_sprites_t3x_start, blob_size);
}

void run_graphics_exit(void) {
    if (original_sheet) { C2D_SpriteSheetFree(original_sheet); original_sheet = NULL; }
}

static void original_image_at(int index,float x,float y,float depth,float sx,float sy) {
    if (!original_sheet || (size_t)index >= C2D_SpriteSheetCount(original_sheet)) return;
    C2D_Image img = C2D_SpriteSheetGetImage(original_sheet,(size_t)index);
    C2D_DrawImageAt(img,x,y,depth,NULL,sx,sy);
}

#define HALF 1.45f
#define FOV 205.0f
#define CAMERA_DEPTH 2.65f
#define CENTER_X 200.0f
#define CENTER_Y 105.0f
#define VIEW_SEGMENTS 16

typedef struct { float x, y; } Point;
static u32 rgba(int r, int g, int b) { return C2D_Color32(r,g,b,255); }

static void face_position(int face, float t, float *x, float *y) {
    switch (face & 3) {
        case 0: *x = -HALF + 2*HALF*t; *y = -HALF; break;
        case 1: *x = HALF; *y = -HALF + 2*HALF*t; break;
        case 2: *x = HALF - 2*HALF*t; *y = HALF; break;
        default: *x = -HALF; *y = HALF - 2*HALF*t; break;
    }
}

static Point project(float x, float y, float depth, float sine, float cosine) {
    float xr = cosine*x - sine*y;
    float yr = sine*x + cosine*y;
    float scale = FOV / fmaxf(.5f, CAMERA_DEPTH + depth);
    Point p = { CENTER_X + xr*scale, CENTER_Y - yr*scale };
    return p;
}

static void quad(Point a, Point b, Point c, Point d, u32 color) {
    C2D_DrawTriangle(a.x,a.y,color,b.x,b.y,color,c.x,c.y,color,.1f);
    C2D_DrawTriangle(a.x,a.y,color,c.x,c.y,color,d.x,d.y,color,.1f);
}

static void stars(const RunGame *g) {
    if (original_sheet && C2D_SpriteSheetCount(original_sheet)>=36) {
        /* SWF resource ID 2: original star bitmap, 550 x 400 pixels. */
        original_image_at(0, 0.0f, -25.0f, 0.01f,
                          400.0f/550.0f, 290.0f/400.0f);
        return;
    }
    for (int i=0; i<56; ++i) {
        uint32_t h = (uint32_t)i * 2654435761u + 0x754ffa0du;
        int x = (int)((h >> 2) % 400u);
        int y = (int)((h >> 15) % 240u);
        x = (x + (int)(g->z * (0.35f + .07f*(i%3)))) % 400;
        C2D_DrawRectSolid((float)x,(float)y,0,(i%11==0)?2:1,1,
                          i%5==0?rgba(178,184,199):rgba(70,77,93));
    }
}

static void tunnel(const RunGame *g) {
    float s = sinf(g->rotation), c = cosf(g->rotation);
    int nearest = (int)floorf(g->z);
    int farthest = nearest + VIEW_SEGMENTS;
    if (g->kind == RUN_ADVENTURE && farthest >= g->length) farthest = g->length-1;
    if (nearest < 0) nearest = 0;
    for (int seg = farthest; seg >= nearest; --seg) {
        float depth_a = (float)seg - g->z;
        float depth_b = depth_a + 1;
        for (int face = 0; face < RUN_FACES; ++face) {
            /* This RGB is embedded with each Adventure level in Run.swf.
               It replaces the previous invented grayscale theme. */
            uint32_t original_color = run_original_levels[g->level].color_rgb;
            int cr=(original_color >> 16)&255, cg=(original_color >> 8)&255, cb=original_color&255;
            int relative=(face-g->face+4)%4;
            float brightness= relative==0 ? 1.0f : relative==1 ? .74f : relative==2 ? .60f : .83f;
            for (int lane=0; lane<RUN_LANES; ++lane) {
                if (!run_tile_at(g,seg,face,lane)) continue;
                /* Platforms MUST share their exact edges. Run Flash draws
                   continuous solid surfaces without black gaps between
                   adjacent tiles. The old .025/.975 margin made 1px-wide
                   fake cracks across every platform and wall. */
                float t0 = (float)lane / RUN_LANES;
                float t1 = ((float)lane + 1.0f) / RUN_LANES;
                float x0,y0,x1,y1;
                face_position(face,t0,&x0,&y0);
                face_position(face,t1,&x1,&y1);
                Point a=project(x0,y0,depth_a,s,c);
                Point b=project(x1,y1,depth_a,s,c);
                Point d=project(x0,y0,depth_b,s,c);
                Point e=project(x1,y1,depth_b,s,c);
                quad(a,b,e,d,rgba((int)(cr*brightness),(int)(cg*brightness),(int)(cb*brightness)));
            }
        }
    }
}

/* Run.swf gray alien vector frames, SWF IDs 186 / 212..231 / 312..325.
   Each atlas frame uses a fixed 2,800-twip rectangle, so no animation jitter. */
static void alien(const RunGame *g) {
    float x = CENTER_X + g->x * 67.0f;
    float y = 199.0f - g->height * 43.0f;
    if (original_sheet && C2D_SpriteSheetCount(original_sheet)>=36) {
        int frame;
        if (g->mode==RUN_TITLE || g->mode==RUN_LEVEL_SELECT || g->mode==RUN_OPTIONS || g->mode==RUN_SETTINGS)
            frame=2; /* actual SWF shape 186, idle */
        else if (g->height>0.06f) {
            int step=(int)(g->height*9.0f);
            if (step>12) step=12;
            frame=23+step; /* original jump frames 312,314..325 */
        } else {
            frame=3+((int)(g->time_elapsed*18.0f)%20); /* original Run frames 212..231 */
        }
        /* Restore actual Run 2008 alien outline, antennae, and moving limbs.
           The PNGs are rasterized directly from the user's Flash vector assets. */
        original_image_at(frame,x-32.0f,y-56.0f,0.35f,1.0f,1.0f);
        return;
    }
    /* Fallback appears only if the embedded original texture fails to load. */
    float stride=sinf(g->time_elapsed*24.0f)*3.2f;
    u32 outline=rgba(29,32,36), body=rgba(212,215,218), eyes=rgba(36,39,42);
    if (g->theme==1) body=rgba(191,231,235);
    if (g->theme==2) body=rgba(247,224,167);
    /* Last-resort placeholder: only visible if sprite atlas import fails. */
    C2D_DrawLine(x-4,y-13,outline,x-7-stride,y+4,outline,4,0.1f);
    C2D_DrawLine(x+4,y-13,outline,x+7+stride,y+4,outline,4,0.1f);
    C2D_DrawLine(x-4,y-27,outline,x-12,y-16+stride,outline,3,0.1f);
    C2D_DrawLine(x+4,y-27,outline,x+12,y-16-stride,outline,3,0.1f);
    C2D_DrawRectSolid(x-6,y-27,0.1f,12,16,outline);
    C2D_DrawRectSolid(x-4,y-25,0.2f,8,12,body);
    C2D_DrawLine(x-5,y-36,outline,x-8,y-43,outline,2,0.1f);
    C2D_DrawLine(x+5,y-36,outline,x+8,y-43,outline,2,0.1f);
    C2D_DrawCircleSolid(x-8,y-44,.1f,2.8f,body);
    C2D_DrawCircleSolid(x+8,y-44,.1f,2.8f,body);
    C2D_DrawCircleSolid(x,y-34,0.1f,12,outline);
    C2D_DrawCircleSolid(x,y-35,0.2f,10,body);
    C2D_DrawCircleSolid(x-3,y-36,0.3f,1.7f,eyes);
    C2D_DrawCircleSolid(x+3,y-36,0.3f,1.7f,eyes);
}

static void draw_label(C2D_TextBuf buffer, const char* msg, float x, float y, float scale, u32 color) {
    C2D_Text text;
    C2D_TextParse(&text,buffer,msg);
    C2D_TextOptimize(&text);
    C2D_DrawText(&text,C2D_WithColor,x,y,.4f,scale,scale,color);
}

/* Original Flash title assets: all these pixels came from the user's
   Run.swf. They are not recreation art. Indices match run_sprites.t3s. */
static void run_title_screen(C2D_TextBuf buf, int menu, int fast) {
    if (original_sheet && C2D_SpriteSheetCount(original_sheet)>=46) {
        original_image_at(1,14,6,.42f,.41f,.41f); /* SWF 'run.' logo */
        original_image_at(36,49,56,.43f,.80f,.65f); /* all 4 SWF labels */
        const float y[4] = {70,101,134,225};
        for(int i=0; i<4; ++i) {
            original_image_at(37,13,y[i]-14,.46f,.29f,.29f);
            if (menu == i) {
                /* Small 3DS selection marker; original labels stay intact. */
                C2D_DrawRectSolid(5,y[i]-8,.49f,2,17,rgba(248,248,248));
            }
        }
        draw_label(buf,"Game speed:",263,174,.60f,rgba(175,175,175));
        original_image_at(39,309,196,.43f,.66f,.66f);
        original_image_at(37,287,198,.44f,.17f,.17f);
        original_image_at(37,287,218,.44f,.17f,.17f);
        original_image_at(40,289,fast ? 220 : 200,.50f,.18f,.18f);
    } else {
        draw_label(buf,"run.",12,8,1.35f,rgba(156,156,156));
        const char* modes[4] = {"Adventure mode","Infinite mode","Edit mode","Credits"};
        const float y[4]={58,90,124,217};
        for(int i=0;i<4;++i) {
            draw_label(buf,modes[i],45,y[i],.75f,rgba(148,148,148));
            if(i==menu) C2D_DrawRectSolid(21,y[i]+2,.4f,7,7,rgba(245,245,245));
        }
        draw_label(buf,"Game speed:  Normal / Fast",234,185,.47f,rgba(180,180,180));
    }
}

void run_render(const RunGame *g, C2D_TextBuf buffer, int menu, int fast, int music_on) {
    C2D_DrawRectSolid(0,0,0,400,240,rgba(4,6,17));
    stars(g);
    if (g->mode!=RUN_TITLE && g->mode!=RUN_LEVEL_SELECT && g->mode!=RUN_OPTIONS && g->mode!=RUN_SETTINGS)
        tunnel(g);
    if (g->mode!=RUN_TITLE && g->mode!=RUN_OPTIONS && g->mode!=RUN_SETTINGS)
        alien(g);
    C2D_TextBufClear(buffer);
    char title[128];
    if (g->mode==RUN_TITLE) {
        run_title_screen(buffer,menu,fast);
    } else if (g->mode==RUN_SETTINGS) {
        if (original_sheet && C2D_SpriteSheetCount(original_sheet)>=36)
            original_image_at(1,28,11,.43f,.60f,.60f);
        draw_label(buffer,"SETTINGS",31,99,.91f,rgba(228,231,237));
        draw_label(buffer,music_on ? "Music: ON" : "Music: OFF",31,139,.82f,rgba(222,228,242));
        draw_label(buffer,"Original Run.swf soundtrack",31,179,.56f,rgba(172,194,218));
    } else if (g->mode==RUN_OPTIONS) {
        if(original_sheet && C2D_SpriteSheetCount(original_sheet)>=46)
            original_image_at(44,28,13,.5f,.92f,.92f);
        else draw_label(buffer,"credits.",29,19,1.0f,rgba(170,170,170));
        draw_label(buffer,"Run by Player_03",28,81,.72f,rgba(195,195,195));
        draw_label(buffer,"Original Flash artwork from your SWF",28,123,.52f,rgba(180,180,180));
        draw_label(buffer,"Press B to return",28,181,.60f,rgba(228,228,228));
    } else if (g->mode==RUN_LEVEL_SELECT) {
        C2D_DrawRectSolid(43,14,.4f,314,87,C2D_Color32(4,4,4,174));
        if (original_sheet && C2D_SpriteSheetCount(original_sheet)>=36)
            original_image_at(1,115.0f,20.0f,0.54f,.71f,.71f);
        else draw_label(buffer,"run.",149,22,.98f,rgba(160,160,160));
        draw_label(buffer,"SELECT ADVENTURE LEVEL",60,79,.61f,rgba(220,220,220));
    } else {
        snprintf(title,sizeof(title),"LEVEL %02d / 50",g->level+1);
        C2D_DrawRectSolid(7,5,.3f,177,25,C2D_Color32(5,8,17,190));
        draw_label(buffer,title,13,8,.53f,rgba(255,255,255));
        float progress=g->z/(float)g->length;
        if (progress > 1) progress=1;
        C2D_DrawRectSolid(13,29,.3f,163*progress,3,rgba(212,225,242));
        const char* tutorial=run_original_levels[g->level].tutorial;
        if (tutorial && g->z < 15.0f) {
            C2D_DrawRectSolid(8,196,.3f,384,35,C2D_Color32(5,8,17,190));
            draw_label(buffer,tutorial,12,205,.43f,rgba(245,245,245));
        }
        if (g->mode == RUN_PAUSED || g->mode == RUN_FINISHED || g->mode == RUN_GAME_OVER) {
            C2D_DrawRectSolid(44,65,.5f,312,97,C2D_Color32(7,10,20,226));
            const char *message = g->mode==RUN_PAUSED ? "PAUSED" : "LEVEL COMPLETE!";
            draw_label(buffer,message,66,83,.78f,rgba(245,247,255));

        }
    }
    if (g->death_flash > 0 && g->mode == RUN_PLAYING)
        C2D_DrawRectSolid(0,0,.6f,400,240,C2D_Color32(245,245,245,(int)(g->death_flash*160)));
}

/* Native lower-screen touch UI (320x240). The top screen remains gameplay. */
static void ui_button(C2D_TextBuf buf, float x,float y,float w,float h,
                      const char *label, int active) {
    u32 bg = active ? rgba(110,110,110) : rgba(39,39,39);
    C2D_DrawRectSolid(x,y,.1f,w,h,bg);
    C2D_DrawRectSolid(x,y,.2f,w,2,rgba(160,160,160));
    draw_label(buf,label,x+11,y+(h>35?13:7),.56f,rgba(245,247,250));
}

void run_render_bottom(const RunGame *g,C2D_TextBuf buf,int menu,int save_available,int fast,int music_on,int settings_save_available) {
    C2D_TextBufClear(buf);
    C2D_DrawRectSolid(0,0,0,320,240,rgba(0,0,0));
    if (original_sheet && C2D_SpriteSheetCount(original_sheet)>=36)
        original_image_at(0,0,0,.01f,320.0f/550.0f,240.0f/400.0f);
    C2D_DrawRectSolid(0,0,.05f,320,38,C2D_Color32(21,21,21,223));
    draw_label(buf,"RUN 1 / NINTENDO 3DS",13,9,.68f,rgba(240,243,250));
    if (g->mode == RUN_TITLE)
        draw_label(buf,run_music_status_text(),222,15,.35f,rgba(211,232,203));
    char label[100];
    if (g->mode==RUN_TITLE) {
        const char *items[]={"Adventure mode","Infinite mode (not ported)",
                             "Edit mode (not ported)","Credits"};
        for(int i=0;i<4;++i) {
            ui_button(buf,16,33+i*39,288,33,items[i],menu==i);
        }
        ui_button(buf,8,197,71,32,fast?"FAST":"NORMAL",0);
        ui_button(buf,82,197,85,32,"LEVELS",0);
        ui_button(buf,170,197,82,32,"SETTINGS",0);
        ui_button(buf,256,197,56,32,"EXIT",0);
    } else if (g->mode==RUN_SETTINGS) {
        draw_label(buf,"MUSIC SETTINGS",17,52,.82f,rgba(235,243,249));
        ui_button(buf,16,89,288,51,music_on ? "MUSIC: ON" : "MUSIC: OFF",1);
        draw_label(buf,"Tap to toggle (or press A)",20,155,.56f,rgba(200,218,231));
        draw_label(buf,settings_save_available ? "Setting saved to SD card" : "Save failed: check SD access",20,179,.49f,rgba(218,218,218));
        ui_button(buf,16,198,288,31,"BACK",0);
    } else if (g->mode==RUN_LEVEL_SELECT) {
        snprintf(label,sizeof(label),"LEVEL %02d / 50",g->selected_level+1);
        draw_label(buf,label,87,54,.85f,rgba(240,243,250));
        snprintf(label,sizeof(label),"Unlocked through %02d",g->unlocked_level+1);
        draw_label(buf,label,87,85,.52f,rgba(180,200,220));
        ui_button(buf,16,112,58,38,"-5",0);
        ui_button(buf,79,112,58,38,"<",0);
        ui_button(buf,143,112,58,38,">",0);
        ui_button(buf,207,112,58,38,"+5",0);
        ui_button(buf,17,169,286,30,
            g->selected_level<=g->unlocked_level?"PLAY LEVEL":"LOCKED",1);
        ui_button(buf,17,204,286,27,"BACK",0);
    } else if (g->mode==RUN_OPTIONS) {
        draw_label(buf,"RUN 1 (FLASH) / PLAYER_03",18,51,.66f,rgba(220,231,242));
        draw_label(buf,"3DS adaptation in progress",18,84,.60f,rgba(220,231,242));
        draw_label(buf,"50 source Adventure maps loaded",18,119,.49f,rgba(220,231,242));
        draw_label(buf,"Infinite + Edit modes not yet ported",18,149,.47f,rgba(220,231,242));
        draw_label(buf,save_available?"Save: available":"Save: unavailable",18,173,.45f,rgba(220,231,242));
        ui_button(buf,16,199,288,30,"BACK",0);
    } else if (g->mode==RUN_PLAYING) {
        snprintf(label,sizeof(label),"LEVEL %02d / 50     FALLS: %d",g->level+1,g->deaths);
        draw_label(buf,label,12,54,.55f,rgba(230,236,242));
        snprintf(label,sizeof(label),"DISTANCE: %d / %d",(int)g->z,g->length);
        draw_label(buf,label,12,79,.55f,rgba(230,236,242));
        ui_button(buf,245,41,59,30,"II",0);
        ui_button(buf,11,137,69,85,"LEFT",0);
        ui_button(buf,89,137,69,85,"RIGHT",0);
        ui_button(buf,167,137,138,85,"JUMP",1);
        draw_label(buf,"D-Pad/Circle Pad   X: MUSIC ON/OFF",12,111,.40f,rgba(170,191,209));
    } else if (g->mode==RUN_PAUSED) {
        draw_label(buf,"PAUSED",97,48,1.1f,rgba(235,243,249));
        ui_button(buf,17,75,286,27,music_on ? "MUSIC ON  (X: MUTE)" : "MUSIC OFF  (X: UNMUTE)",0);
        ui_button(buf,17,105,286,37,"RESUME",1);
        ui_button(buf,17,150,286,37,"RESTART",0);
        ui_button(buf,17,195,286,37,"MAIN MENU",0);
    } else if (g->mode==RUN_FINISHED) {
        draw_label(buf,"LEVEL COMPLETE!",38,58,.95f,rgba(242,248,252));
        ui_button(buf,17,105,286,37,g->level<49?"NEXT LEVEL":"MAIN MENU",1);
        ui_button(buf,17,150,286,37,"REPLAY",0);
        ui_button(buf,17,195,286,37,"MAIN MENU",0);
    }
}
