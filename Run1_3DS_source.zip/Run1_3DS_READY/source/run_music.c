#include <3ds.h>
#include <3ds/ndsp/ndsp.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "run_music.h"

/* Original Run.swf sound 643; 22,050 Hz mono s16le PCM in read-only ROM.
   Only 32 KiB of additional linear RAM is used for NDSP stream buffers. */
extern const unsigned char run_music_pcm_start[];
extern const unsigned char run_music_pcm_end[];

#define MUSIC_CHANNEL 0
#define MUSIC_RATE 22050
#define MUSIC_BUFFER_SAMPLES 4096
#define MUSIC_BUFFER_COUNT 4

static s16 *music_buffers = NULL;
static ndspWaveBuf wavebuf[MUSIC_BUFFER_COUNT];
static size_t music_sample_count = 0;
static size_t music_sample_cursor = 0;
static bool music_available = false;
static bool music_playing = false;
static const char *music_status = "MUSIC OFF";
static const char *music_error = "MUSIC UNAVAILABLE";

static void queue_buffer(int i) {
    s16 *dst = music_buffers + (i * MUSIC_BUFFER_SAMPLES);
    const unsigned char *src = run_music_pcm_start;
    size_t pos = music_sample_cursor;
    for (size_t n = 0; n < MUSIC_BUFFER_SAMPLES; ++n) {
        memcpy(&dst[n], src + pos * 2, sizeof(s16));
        if (++pos == music_sample_count) pos = 0;
    }
    music_sample_cursor = pos;
    DSP_FlushDataCache(dst, MUSIC_BUFFER_SAMPLES * sizeof(s16));
    wavebuf[i].data_pcm16 = dst;
    wavebuf[i].nsamples = MUSIC_BUFFER_SAMPLES;
    wavebuf[i].looping = false;
    ndspChnWaveBufAdd(MUSIC_CHANNEL, &wavebuf[i]);
}

void run_music_set_enabled(int enabled) {
    if (!enabled) {
        if (music_available && music_playing) {
            ndspChnWaveBufClear(MUSIC_CHANNEL);
            memset(wavebuf, 0, sizeof(wavebuf));
        }
        music_playing = false;
        music_status = "MUSIC OFF";
        return;
    }
    if (!music_available) {
        music_playing = false;
        music_status = music_error;
        return;
    }
    if (!music_playing) {
        ndspChnWaveBufClear(MUSIC_CHANNEL);
        memset(wavebuf, 0, sizeof(wavebuf));
        for (int i = 0; i < MUSIC_BUFFER_COUNT; ++i) queue_buffer(i);
        music_playing = true;
    }
    music_status = "MUSIC ON";
}

void run_music_init(int start_enabled) {
    music_playing = false;
    music_available = false;
    music_buffers = NULL;
    music_status = "MUSIC OFF";
    music_sample_count = (size_t)(run_music_pcm_end - run_music_pcm_start) / 2;
    music_sample_cursor = 0;
    if (music_sample_count < MUSIC_BUFFER_SAMPLES) {
        music_error = "MUSIC DATA ERROR";
        run_music_set_enabled(start_enabled);
        return;
    }
    if (R_FAILED(ndspInit())) {
        music_error = "MUSIC DSP UNAVAILABLE";
        run_music_set_enabled(start_enabled);
        return;
    }
    music_buffers = (s16*)linearAlloc(MUSIC_BUFFER_COUNT * MUSIC_BUFFER_SAMPLES * sizeof(s16));
    if (!music_buffers) {
        music_error = "MUSIC MEMORY ERROR";
        ndspExit();
        run_music_set_enabled(start_enabled);
        return;
    }
    memset(wavebuf, 0, sizeof(wavebuf));
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    ndspChnReset(MUSIC_CHANNEL);
    ndspChnSetInterp(MUSIC_CHANNEL, NDSP_INTERP_LINEAR);
    ndspChnSetRate(MUSIC_CHANNEL, MUSIC_RATE);
    ndspChnSetFormat(MUSIC_CHANNEL, NDSP_FORMAT_MONO_PCM16);
    float mix[12] = {0};
    mix[0] = 0.65f;
    mix[1] = 0.65f;
    ndspChnSetMix(MUSIC_CHANNEL, mix);
    music_available = true;
    run_music_set_enabled(start_enabled);
}

void run_music_update(void) {
    if (!music_available || !music_playing) return;
    for (int i = 0; i < MUSIC_BUFFER_COUNT; ++i)
        if (wavebuf[i].status == NDSP_WBUF_DONE) queue_buffer(i);
}

void run_music_exit(void) {
    if (music_available) {
        ndspChnWaveBufClear(MUSIC_CHANNEL);
        ndspExit();
        linearFree(music_buffers);
    }
    music_available = false;
    music_playing = false;
    music_buffers = NULL;
}

const char *run_music_status_text(void) { return music_status; }
