#include "game.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>

typedef struct {
    uint32_t magic, version, unlocked, deaths, best, theme, finished, checksum;
} RunSave;

static uint32_t checksum(const RunSave *s) {
    const uint32_t *items = (const uint32_t *)s;
    uint32_t result = 2166136261u;
    for (int i = 0; i < 7; ++i) {
        uint32_t v = items[i];
        for (int j = 0; j < 4; ++j) {
            result ^= (v >> (j * 8)) & 255u;
            result *= 16777619u;
        }
    }
    return result;
}

int run_save_write(const RunGame *g, const char *path) {
    if (!g || !path) return 0;
    RunSave s;
    memset(&s, 0, sizeof s);
    s.magic = 0x53314452u; /* R D 1 S, little endian */
    s.version = 2;
    s.unlocked = (uint32_t)g->unlocked_level;
    s.deaths = (uint32_t)g->total_deaths;
    s.best = (uint32_t)g->best_infinite;
    s.theme = (uint32_t)g->theme;
    s.finished = (uint32_t)g->finished_adventure;
    s.checksum = checksum(&s);
    FILE *file = fopen(path, "wb");
    if (!file) return 0;
    int ok = fwrite(&s, sizeof s, 1, file) == 1;
    if (fclose(file) != 0) ok = 0;
    return ok;
}

int run_save_read(RunGame *g, const char *path) {
    if (!g || !path) return 0;
    FILE *file = fopen(path, "rb");
    if (!file) return 0;
    RunSave s;
    int ok = fread(&s, sizeof s, 1, file) == 1;
    fclose(file);
    if (!ok || s.magic != 0x53314452u || s.version != 2 || checksum(&s) != s.checksum)
        return 0;
    if (s.unlocked >= RUN_ADVENTURE_LEVELS || s.theme > 2 || s.finished > 1) return 0;
    g->unlocked_level = (int)s.unlocked;
    g->total_deaths = (int)s.deaths;
    g->best_infinite = (int)s.best;
    g->theme = (int)s.theme;
    g->finished_adventure = (int)s.finished;
    g->dirty = 0;
    return 1;
}

/* Settings v1 lives in a separate file, preserving existing v2 Adventure saves.
   The checksum and exact 16-byte file length prevent corrupted settings from
   unexpectedly changing the user's audio preference. */
typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t music_on;
    uint32_t checksum;
} RunSettingsSave;

static uint32_t settings_checksum(const RunSettingsSave *s) {
    uint32_t hash = 2166136261u;
    const uint32_t data[3] = {s->magic, s->version, s->music_on};
    for (int i = 0; i < 3; ++i) {
        for (int b = 0; b < 4; ++b) {
            hash ^= (data[i] >> (8*b)) & 0xFFu;
            hash *= 16777619u;
        }
    }
    return hash;
}

int run_settings_save_write(int music_on, const char *path) {
    if (!path || (music_on != 0 && music_on != 1)) return 0;
    RunSettingsSave s = {0};
    s.magic = 0x53554D52u; /* "RMUS" on a little-endian system */
    s.version = 1;
    s.music_on = (uint32_t)music_on;
    s.checksum = settings_checksum(&s);
    FILE *file = fopen(path, "wb");
    if (!file) return 0;
    int ok = fwrite(&s, sizeof(s), 1, file) == 1;
    if (fclose(file) != 0) ok = 0;
    return ok;
}

int run_settings_save_read(int *music_on, const char *path) {
    if (!music_on || !path) return 0;
    FILE *file = fopen(path, "rb");
    if (!file) return 0;
    RunSettingsSave s;
    int ok = fread(&s, sizeof(s), 1, file) == 1;
    int end = fgetc(file);
    fclose(file);
    if (!ok || end != EOF || s.magic != 0x53554D52u || s.version != 1 ||
        s.music_on > 1 || s.checksum != settings_checksum(&s)) return 0;
    *music_on = (int)s.music_on;
    return 1;
}
