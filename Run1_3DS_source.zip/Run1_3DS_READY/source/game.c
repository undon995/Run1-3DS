#include "game.h"
#include "original_maps.h"
#include <math.h>
#include <string.h>

/* Native 3DS physics implementation. These tuning values have NOT yet been
   measured against original Flash game timing. Level geometry IS original. */
#define HALF_WIDTH 1.45f
#define PI 3.14159265358979323846f
#define FORWARD_SPEED 5.65f
#define SIDE_ACCEL 16.0f
#define SIDE_MAX 3.15f
#define JUMP_VEL 6.65f
#define GRAVITY 17.8f

uint16_t run_original_word_at(int level, int segment) {
    if (level < 0 || level >= RUN_ADVENTURE_LEVELS) return 0;
    const RunOriginalLevel *l = &run_original_levels[level];
    if (segment < 0 || segment >= l->length) return 0;
    return run_original_words[l->offset + (unsigned)segment];
}

/* Byte-accurate wall decode derived from Run.swf AS3 level parser
   (_-68::ctor, SWF method 11). Flash lays out each 16-bit row as a
   6x6 perimeter, where four HEX nibbles are read in this exact order:

       nibble A (bits 15..12)  right wall, bottom -> top
       nibble B (bits 11.. 8)  floor,      left -> right
       nibble C (bits  7.. 4)  left wall,  top -> bottom
       nibble D (bits  3.. 0)  ceiling,    right -> left

   IMPORTANT: The previous engine swapped all four walls; for example,
   original 0x0F00 is a continuous FLOOR, not a left wall.
   The renderer's clockwise faces use floor=0, right=1, top=2, left=3,
   with lane zero at the first end of each arrow above. */
static uint8_t original_tile(uint16_t word, int face, int lane) {
    static const unsigned shift_by_face[RUN_FACES] = {8, 12, 0, 4};
    unsigned nibble = (word >> shift_by_face[face]) & 15u;
    return (uint8_t)((nibble >> (unsigned)lane) & 1u);
}

static void load_original_adventure(RunGame *g, int level) {
    const RunOriginalLevel *desc = &run_original_levels[level];
    g->length = desc->length;
    memset(g->tiles, 0, sizeof(g->tiles));
    for (int s = 0; s < g->length; ++s) {
        uint16_t word = run_original_words[desc->offset + (unsigned)s];
        for (int f = 0; f < RUN_FACES; ++f)
            for (int lane = 0; lane < RUN_LANES; ++lane)
                g->tiles[s][f][lane] = original_tile(word, f, lane);
    }
}

/* Spawn position is inferred from genuine starting tiles, pending recovery of
   original player's spawn/orientation constants. No map tiles are modified. */
static void reset_runner(RunGame *g) {
    int face = 0, lane = 1;
    int strongest = -9999;
    for (int f = 0; f < RUN_FACES; ++f)
        for (int l = 0; l < RUN_LANES; ++l) {
            int score = 0;
            for (int s = 0; s < g->length && s < 5; ++s)
                score += g->tiles[s][f][l] ? 1 : 0;
            /* Favor a centered floor spawn on ties; never invent support. */
            int preference = score * 100 - (l == 1 || l == 2 ? 0 : 10) - (f == 0 ? 0 : 2);
            if (preference > strongest) { strongest = preference; face = f; lane = l; }
        }
    g->face = face;
    g->z = 0.20f;
    g->x = ((float)lane + 0.5f) / RUN_LANES * (2.0f * HALF_WIDTH) - HALF_WIDTH;
    g->height = 0;
    g->vertical_velocity = 0;
    g->lateral_velocity = 0;
    g->rotation = -(float)face * (PI * 0.5f);
    g->coyote = 0.085f;
    g->jump_buffer = 0;
    g->death_flash = 0;
    g->time_elapsed = 0;
}

void run_init(RunGame *g) {
    memset(g, 0, sizeof(*g));
    g->mode = RUN_TITLE;
    g->kind = RUN_ADVENTURE;
    load_original_adventure(g, 0);
    reset_runner(g);
}

void run_start_level(RunGame *g, int level) {
    if (level < 0) level = 0;
    if (level >= RUN_ADVENTURE_LEVELS) level = RUN_ADVENTURE_LEVELS - 1;
    g->kind = RUN_ADVENTURE;
    g->level = level;
    g->deaths = 0;
    load_original_adventure(g, level);
    reset_runner(g);
    g->mode = RUN_PLAYING;
}

/* Infinite Mode is deliberately DISABLED. The original Flash game's random
   course algorithm still needs to be recovered; no imitation is substituted. */
void run_start_infinite(RunGame *g) { (void)g; }
void run_prepare_visible(RunGame *g) { (void)g; }
int run_infinite_difficulty(const RunGame *g) { (void)g; return 0; }

void run_restart(RunGame *g) { run_start_level(g, g->level); }

int run_tile_at(const RunGame *g, int segment, int face, int lane) {
    if (segment < 0 || segment >= g->length ||
        face < 0 || face >= RUN_FACES || lane < 0 || lane >= RUN_LANES)
        return 0;
    return g->tiles[segment][face][lane] != 0;
}

int run_current_lane(const RunGame *g) {
    int lane = (int)floorf((g->x + HALF_WIDTH) / (2.0f * HALF_WIDTH) * RUN_LANES);
    if (lane < 0) lane = 0;
    if (lane >= RUN_LANES) lane = RUN_LANES - 1;
    return lane;
}

static void death(RunGame *g) {
    ++g->total_deaths;
    ++g->deaths;
    g->dirty = 1;
    reset_runner(g);
    g->death_flash = 0.28f;
}

void run_update(RunGame *g, float dt, float movement, int jump_pressed) {
    if (g->mode != RUN_PLAYING) return;
    if (dt < 0) dt = 0;
    if (dt > 0.04f) dt = 0.04f;
    g->time_elapsed += dt;
    if (g->death_flash > 0) g->death_flash -= dt;
    if (movement < -1) movement = -1;
    if (movement > 1) movement = 1;

    if (jump_pressed) g->jump_buffer = 0.10f;
    else if (g->jump_buffer > 0) g->jump_buffer -= dt;
    float target_velocity = movement * SIDE_MAX;
    float step = SIDE_ACCEL * dt;
    if (g->lateral_velocity < target_velocity - step) g->lateral_velocity += step;
    else if (g->lateral_velocity > target_velocity + step) g->lateral_velocity -= step;
    else g->lateral_velocity = target_velocity;
    g->x += g->lateral_velocity * dt;
    if (g->x >= HALF_WIDTH) {
        g->x -= 2 * HALF_WIDTH;
        g->face = (g->face + 1) % 4;
    }
    if (g->x < -HALF_WIDTH) {
        g->x += 2 * HALF_WIDTH;
        g->face = (g->face + 3) % 4;
    }

    int seg = (int)floorf(g->z);
    int supported = run_tile_at(g, seg, g->face, run_current_lane(g));
    if (supported && g->height <= 0.01f && g->height >= -0.18f) g->coyote = 0.085f;
    else g->coyote -= dt;
    if (g->coyote < 0) g->coyote = 0;
    if (g->jump_buffer > 0 && g->coyote > 0 && g->height <= 0.01f) {
        g->vertical_velocity = JUMP_VEL;
        g->height = 0.001f;
        g->jump_buffer = 0;
        g->coyote = 0;
    }
    g->vertical_velocity -= GRAVITY * dt;
    g->height += g->vertical_velocity * dt;
    g->z += FORWARD_SPEED * dt;
    seg = (int)floorf(g->z);
    supported = run_tile_at(g, seg, g->face, run_current_lane(g));
    if (g->height <= 0 && supported && g->height >= -0.18f) {
        g->height = 0;
        g->vertical_velocity = 0;
    }
    if (g->height < -1.0f) { death(g); return; }
    if (g->z >= (float)(g->length - 1)) {
        if (g->level == RUN_ADVENTURE_LEVELS - 1) g->finished_adventure = 1;
        else if (g->unlocked_level < g->level + 1) g->unlocked_level = g->level + 1;
        g->dirty = 1;
        g->mode = RUN_FINISHED;
    }

    float target = -(float)g->face * (PI * 0.5f);
    float delta = target - g->rotation;
    while (delta > PI) delta -= PI * 2;
    while (delta < -PI) delta += PI * 2;
    g->rotation += delta * fminf(1.0f, dt * 11.0f);
}
