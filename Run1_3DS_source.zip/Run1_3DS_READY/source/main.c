#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/stat.h>
#include "game.h"
#include "run_music.h"

#define SAVE_DIR "sdmc:/3ds/Run1_2008_3DS"
#define SAVE_PATH SAVE_DIR "/save.dat"
#define SETTINGS_PATH SAVE_DIR "/settings.dat"

void run_graphics_init(void);
void run_graphics_exit(void);
void run_render(const RunGame *g, C2D_TextBuf buffer, int menu, int fast, int music_on);
void run_render_bottom(const RunGame *g, C2D_TextBuf buffer, int menu, int save_available, int fast, int music_on, int settings_save_available);

static bool touch_hit(const touchPosition *touch, bool enabled, int x,int y,int w,int h) {
    return enabled && touch->px>=x && touch->px<x+w && touch->py>=y && touch->py<y+h;
}

/* Returns true when the title-screen Exit command was selected. */
static bool update_input(RunGame *g, int *menu, int *fast, int *music_on, u32 down, u32 held,
                         const touchPosition *touch) {
    bool pressed=(down & KEY_TOUCH)!=0;
    bool touching=(held & KEY_TOUCH)!=0;
    if (g->mode == RUN_TITLE) {
        /* SWF title menu order: Adventure / Infinite / Edit / Credits.
           Game speed is a separate selection, just like the Flash menu. */
        if (down & KEY_DUP)   *menu = (*menu + 3) % 4;
        if (down & KEY_DDOWN) *menu = (*menu + 1) % 4;
        if (down & KEY_X) *fast = !*fast;
        if (down & KEY_R) { g->mode=RUN_SETTINGS; return false; }
        if (down & KEY_Y) {
            g->selected_level=g->unlocked_level;
            g->mode=RUN_LEVEL_SELECT;
            return false;
        }
        for (int i=0; i<4; ++i) {
            if (touch_hit(touch,pressed,16,33+i*39,288,33)) {
                *menu=i;
                down |= KEY_A;
                break;
            }
        }
        if (touch_hit(touch,pressed,8,197,71,32)) *fast = !*fast;
        if (touch_hit(touch,pressed,170,197,82,32)) { g->mode=RUN_SETTINGS; return false; }
        if (touch_hit(touch,pressed,82,197,85,32)) {
            g->selected_level=g->unlocked_level;
            g->mode=RUN_LEVEL_SELECT;
            return false;
        }
        if (touch_hit(touch,pressed,256,197,56,32)) return true;
        if (down & KEY_A) {
            switch (*menu) {
                case 0: run_start_level(g,g->unlocked_level); break;
                case 1: /* Original Infinite Mode isn't implemented yet. */ break;
                case 2: /* Original Edit Mode isn't implemented yet. */ break;
                case 3: g->mode=RUN_OPTIONS; break; /* Credits screen */
            }
        }
    } else if (g->mode == RUN_SETTINGS) {
        if ((down & (KEY_A|KEY_X)) || touch_hit(touch,pressed,16,89,288,51))
            *music_on = !*music_on;
        if ((down & KEY_B) || touch_hit(touch,pressed,16,198,288,31))
            g->mode=RUN_TITLE;
    } else if (g->mode == RUN_LEVEL_SELECT) {
        if (down & KEY_DLEFT) --g->selected_level;
        if (down & KEY_DRIGHT) ++g->selected_level;
        if (down & KEY_L) g->selected_level -= 5;
        if (down & KEY_R) g->selected_level += 5;
        if (touch_hit(touch,pressed,16,112,58,38)) g->selected_level-=5;
        if (touch_hit(touch,pressed,79,112,58,38)) --g->selected_level;
        if (touch_hit(touch,pressed,143,112,58,38)) ++g->selected_level;
        if (touch_hit(touch,pressed,207,112,58,38)) g->selected_level+=5;
        if (g->selected_level<0) g->selected_level=0;
        if (g->selected_level>=RUN_ADVENTURE_LEVELS) g->selected_level=RUN_ADVENTURE_LEVELS-1;
        if ((down & KEY_B) || touch_hit(touch,pressed,17,204,286,27))
            g->mode=RUN_TITLE;
        else if (((down & KEY_A) || touch_hit(touch,pressed,17,169,286,30)) &&
                 g->selected_level<=g->unlocked_level)
            run_start_level(g,g->selected_level);
    } else if (g->mode == RUN_OPTIONS) {
        if ((down & KEY_B) || touch_hit(touch,pressed,16,199,288,30)) g->mode=RUN_TITLE;
    } else if (g->mode == RUN_PLAYING) {
        if (down & KEY_X) *music_on = !*music_on;
        if ((down & KEY_START) || touch_hit(touch,pressed,245,41,59,30))
            g->mode=RUN_PAUSED;
        else if (down & KEY_SELECT) run_restart(g);
        else {
            circlePosition stick;
            hidCircleRead(&stick);
            float steering=0;
            if (held & KEY_DLEFT) steering-=1;
            if (held & KEY_DRIGHT) steering+=1;
            if (steering==0 && (stick.dx>30 || stick.dx< -30)) {
                steering=(float)stick.dx/156.0f;
                if(steering>1) steering=1;
                if(steering< -1) steering=-1;
            }
            if(touch_hit(touch,touching,11,137,69,85)) steering=-1;
            if(touch_hit(touch,touching,89,137,69,85)) steering=1;
            int jump=(down & (KEY_A|KEY_B))!=0 ||
                touch_hit(touch,pressed,167,137,138,85);
            /* Fast setting provides a faster native simulation; unlike the
               title ART, its exact Flash multiplier still needs measurement. */
            run_update(g,(fast ? 1.35f : 1.0f)/60.0f,steering,jump);
        }
    } else if (g->mode == RUN_PAUSED) {
        if ((down & KEY_X) || touch_hit(touch,pressed,17,75,286,27))
            *music_on = !*music_on;
        else if ((down & (KEY_START|KEY_A)) || touch_hit(touch,pressed,17,105,286,37))
            g->mode=RUN_PLAYING;
        else if ((down & KEY_SELECT) || touch_hit(touch,pressed,17,150,286,37))
            run_restart(g);
        else if ((down & KEY_B) || touch_hit(touch,pressed,17,195,286,37))
            g->mode=RUN_TITLE;
    } else if (g->mode == RUN_FINISHED) {
        if ((down & KEY_A) || touch_hit(touch,pressed,17,105,286,37)) {
            if (g->level<RUN_ADVENTURE_LEVELS-1) run_start_level(g,g->level+1);
            else g->mode=RUN_TITLE;
        } else if ((down & KEY_B) || touch_hit(touch,pressed,17,150,286,37))
            run_restart(g);
        else if ((down & KEY_X) || touch_hit(touch,pressed,17,195,286,37))
            g->mode=RUN_TITLE;
    }
    return false;
}

int main(int argc,char **argv) {
    (void)argc; (void)argv;
    gfxInitDefault();
    if (!C3D_Init(C3D_DEFAULT_CMDBUF_SIZE)) { gfxExit();return 1; }
    if (!C2D_Init(C2D_DEFAULT_MAX_OBJECTS)) { C3D_Fini(); gfxExit(); return 1; }
    C2D_Prepare();
    run_graphics_init();
    C3D_RenderTarget *top=C2D_CreateScreenTarget(GFX_TOP,GFX_LEFT);
    C3D_RenderTarget *bottom=C2D_CreateScreenTarget(GFX_BOTTOM,GFX_LEFT);
    C2D_TextBuf tbuf=C2D_TextBufNew(4096);
    C2D_TextBuf bbuf=C2D_TextBufNew(4096);
    if(!top || !bottom || !tbuf || !bbuf) {
        if(tbuf)C2D_TextBufDelete(tbuf);
        if(bbuf)C2D_TextBufDelete(bbuf);
        run_music_exit();run_graphics_exit();C2D_Fini();C3D_Fini();gfxExit();return 1;
    }
    mkdir(SAVE_DIR,0777);
    RunGame game;
    run_init(&game);
    run_save_read(&game,SAVE_PATH);
    int music_on=1; /* Default ON; older Adventure saves remain intact. */
    run_settings_save_read(&music_on,SETTINGS_PATH);
    run_music_init(music_on);
    int menu=0;
    int fast=0; /* User-selectable Normal/Fast speed; resets upon exit. */
    int save_available=1;
    int settings_save_available=1;
    while(aptMainLoop()) {
        run_music_update();
        hidScanInput();
        u32 down=hidKeysDown(), held=hidKeysHeld();
        touchPosition touch={0};
        if(held & KEY_TOUCH) hidTouchRead(&touch);
        if(game.mode==RUN_TITLE && (down & KEY_START)) break;
        int old_music_on=music_on;
        if(update_input(&game,&menu,&fast,&music_on,down,held,&touch)) break;
        if(old_music_on != music_on) {
            run_music_set_enabled(music_on);
            settings_save_available = run_settings_save_write(music_on,SETTINGS_PATH);
        }
        if(game.dirty && game.mode!=RUN_PLAYING) {
            if(run_save_write(&game,SAVE_PATH)) game.dirty=0;
            else save_available=0;
        }
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(top,C2D_Color32(4,6,17,255));
        C2D_SceneBegin(top);
        run_render(&game,tbuf,menu,fast,music_on);
        C2D_TargetClear(bottom,C2D_Color32(6,13,26,255));
        C2D_SceneBegin(bottom);
        run_render_bottom(&game,bbuf,menu,save_available,fast,music_on,settings_save_available);
        C3D_FrameEnd(0);
    }
    if(game.dirty)run_save_write(&game,SAVE_PATH);
    run_settings_save_write(music_on,SETTINGS_PATH);
    C2D_TextBufDelete(tbuf);
    C2D_TextBufDelete(bbuf);
    run_music_exit();
    run_graphics_exit();
    C2D_Fini();C3D_Fini();gfxExit();return 0;
}
