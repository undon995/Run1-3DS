    .section .rodata
    .balign 16
    .global run_music_pcm_start
run_music_pcm_start:
    .incbin "../assets/original_run_music_22050_mono_s16le.pcm"
    .global run_music_pcm_end
run_music_pcm_end:
    .balign 4
