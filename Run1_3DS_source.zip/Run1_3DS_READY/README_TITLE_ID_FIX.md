# Run 1 3DS — separate Title ID fix

Your previous Run CIA used `UniqueId: 0xF8124`, which could collide with another installed homebrew app such as Impossible Game. This build uses `UniqueId: 0xFF7A6` (application title ID `000400000FF7A600`) and product code `CTR-P-RN3D`. Only the 3DS installation identity and output CIA filename have changed. No game assets, maps, sound, or gameplay code were modified.

**New CIA output:** `Run1_2008_3DS_V07_NEW_TITLE_ID.cia`

## Fastest fix for an existing V0.7 folder
Download `Run1_3DS_V07_Title_ID_FIX_OVERLAY.zip` into Windows Downloads. In devkitPro MSYS2:

```bash
cd /c/Users/natha/Downloads
unzip -o Run1_3DS_V07_Title_ID_FIX_OVERLAY.zip
cd Run1_3DS_V07_Original_Banner
bash BUILD_CIA_MSYS2.sh
```

The overlay overwrites only `project.rsf`, `BUILD_CIA_MSYS2.sh`, and adds this note. It keeps your existing `makerom.exe` and `bannertool.exe` (if already present) and existing assets untouched.

## Alternative full project
If you don't have the old V0.7 folder, extract `Run1_3DS_V07_Separate_TitleID_FULL.zip` and build it:

```bash
cd /c/Users/natha/Downloads
unzip -o Run1_3DS_V07_Separate_TitleID_FULL.zip
cd Run1_3DS_V07_Separate_TitleID
bash BUILD_CIA_MSYS2.sh
```

The scripts look for `bannertool.exe` and `makerom.exe` in your earlier Run V0.3 folder, or you can copy them into the project folder.

## Install
Install `Run1_2008_3DS_V07_NEW_TITLE_ID.cia` in Azahar. Because the application Title ID has changed, it should install alongside Impossible Game rather than offering to replace it. If Impossible Game was already overwritten by the prior Run CIA, installing this new Run CIA won't automatically restore Impossible Game: reinstall the original Impossible Game CIA separately. Keep backups of emulator saves before uninstalling anything.

This is a source patch, not a precompiled CIA. No CIA build/emulator validation was possible here.
