#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
bash BUILD_BOTH_MSYS2.sh
