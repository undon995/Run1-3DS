# Run 1 3DS — V0.3 Original SWF Graphics (tex3ds FIX)

**What this update changes**

- Replaces the C2D primitive placeholder character with **34 original gray alien vector frames** rasterized straight from the user-supplied `Run.swf` (SWF shape IDs 186, 212–231, 312, 314–325).
- Uses the **original `run.` Flash vector logo**, SWF shape ID 678.
- Uses the **actual 550×400 starfield bitmap** from `Run.swf`, SWF bitmap ID 2. This is the image visible behind the original title menu, not a generated star field.
- Keeps all **50 extracted Adventure Mode map layouts** (3,276 original 16-bit tunnel rows), original stage colors, save support, touch controls and 3DS button controls.
- Retains **the two user-supplied images** for the 3DS HOME Menu banner and icon; no AI-generated replacements are used in this project.
- Embeds a single texture atlas inside the game executable, so the CIA does not require external SD/ROMFS image files.

**Important scope:** This is still a *native engine reconstruction with original SWF data and graphics*, **not the complete original Flash code running on 3DS**. Physics, character animation *timing/selection*, collision, sound effects/music, infinite mode and menu behavior are not yet 1:1. The frame images themselves are original.

## Build a CIA (Windows / devkitPro MSYS2)

1. Extract the entire ZIP to `C:\Users\natha\Downloads\Run1_Original_Maps_3DS_CIA_V03_OG_Alien` (do not open the ZIP as a folder).
2. Keep your existing `bannertool.exe` and `makerom.exe` in the older sibling `Run1_Original_Maps_3DS_CIA_V02` directory. The script searches that sibling automatically. Alternatively put both `.exe` files in this V0.3 folder.
3. In devkitPro MSYS2 run:

```bash
cd /c/Users/natha/Downloads/Run1_Original_Maps_3DS_CIA_V03_OG_Alien
bash BUILD_CIA_MSYS2.sh
```

The script runs `tex3ds` to convert the authentic sprite PNGs to a small GPU texture atlas, builds the native `.elf` / `.3dsx`, and then creates `Run1_2008_3DS_OG_ALIEN_V03.cia` with bannertool and makerom.

If `tex3ds` is not found, check `ls /opt/devkitpro/tools/bin/tex3ds*` and your devkitPro 3DS packages.

## Build Homebrew `.3dsx`

```bash
bash BUILD_MSYS2.sh
```

## Image-source verification

`original_graphics_manifest.json` lists the SWF tag or vector shape ID for every extracted image and the SHA256 of the uploaded Flash file. The `assets/original_run_swf/` folder contains all the original rasterized sprites. `SWF_original_alien_frames_preview.png` is a contact sheet of extracted SWF artwork, not a gameplay screenshot.

## Tests performed

- Desktop C unit tests for the original level decoder, input progression and saves: **PASS**.
- Source asset parsing and rasterizing: **PASS**, original star background and 34 alien frames extracted.
- CIA build or Azahar/Old 3DS hardware testing: **NOT performed here** because the devkitARM toolchain isn't present in this environment. Please report compilation errors, crashes or gameplay mismatches after testing.

## Controls

- Circle Pad or D-Pad L/R: lateral movement and tunnel rotation.
- A / B: jump.
- START: pause. SELECT: restart.
- Lower touchscreen: move, jump and menu controls.

## Fix for Windows tex3ds `unknown option -- a` / `unknown option -- b`

The command in both `BUILD_CIA_MSYS2.sh` and `BUILD_MSYS2.sh` now uses
`--atlas -f rgba4 -z none -i run_sprites.t3s -o assets/run_sprites.t3x`.
The optional `-b transparent` flag has been removed because some installed
Windows `tex3ds` versions reject it. This does not modify any of the PNGs.

To apply the fixed package to your existing V0.3 directory **without deleting
`bannertool.exe` or `makerom.exe`**, extract this updated ZIP from Downloads:

```bash
cd /c/Users/natha/Downloads
unzip -o Run1_Original_Maps_3DS_CIA_V03_TEX3DS_FIXED.zip
cd Run1_Original_Maps_3DS_CIA_V03_OG_Alien
bash BUILD_CIA_MSYS2.sh
```

The updated ZIP intentionally retains the older `V03_OG_Alien` top-level
folder name so it updates the same project directory that already contains
your downloaded executables. It includes **source**, **assets** and scripts,
not a precompiled CIA.
