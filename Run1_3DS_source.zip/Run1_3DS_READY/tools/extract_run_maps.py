#!/usr/bin/env python3
"""Extract original 50 Run Adventure maps from a user-supplied Run.swf or Archive ZIP.
Maps are extracted by reading the 50 string literal arguments of the actual
`advLevels` array allocation in the AS3 bytecode. No levels are fabricated.
Usage: python tools/extract_run_maps.py run_20211217.zip
       python tools/extract_run_maps.py Run.swf
Only extracts data from a local file you supply; does not download games.
"""
import argparse, os, re, sys, json, hashlib
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('source', help='A local Run.swf file or ZIP containing Run.swf')
 p.add_argument('--output',default=None,help='Project root (default parent of tools directory)')
 args=p.parse_args()
 os.environ['RUN_SWF']=str(Path(args.source).resolve())
 from parse_run_full import ABC,abc
 from run_disasm import disasm
 root=Path(args.output).resolve() if args.output else Path(__file__).resolve().parent.parent
 target=root/'source'/'original_maps.c'
 maps=[]; colors=[]
 for part in abc:
  a=ABC(part)
  for body in a.bodies:
   ins=disasm(a,body['code'])
   # Find 50 consecutive pushstring instructions followed by newarray 50,
   # then initproperty advLevels, as seen in Run 1's AS3 bytecode.
   for k in range(50,len(ins)-1):
    op=ins[k][1];arg=ins[k][2]
    if not ((op=='newarray' and arg=='50') or (op=='constructprop' and arg.endswith(' 50'))):continue
    block=ins[k-50:k]
    if any(i[1]!='pushstring' for i in block):continue
    nxt=ins[k+1]
    if nxt[1]!='initproperty':continue
    name=nxt[2]
    values=[a.strings[int(i[2].split(':')[0])] for i in block]
    if 'advLevels' in name:
     if maps:raise ValueError('Found duplicate advLevels array')
     maps=values
    elif all(s and s.startswith('|0x') for s in values):
     colors=values
 if len(maps)!=50:
  raise RuntimeError('Could not find exactly 50 original maps in the advLevels bytecode')
 raw_words=[]; lengths=[]; offsets=[]; warnings=[]
 for i,s in enumerate(maps):
  head=s.split('|',1)[0]
  if not head.startswith('0x'):raise ValueError('Map not hex')
  digits=head[2:]
  if not re.fullmatch(r'[0-9A-Fa-f]*',digits):raise ValueError('Map contains nonhex chars')
  if len(digits)%4: warnings.append(f'Level {i+1}: original string has {len(digits)%4} unused trailing hex characters (Flash ignores these)')
  num=len(digits)//4
  offsets.append(len(raw_words));lengths.append(num)
  raw_words.extend(int(digits[j*4:j*4+4],16) for j in range(num))
 if not colors: colors=['|0xD3D3D3']*50;warnings.append('No level color array found; using a neutral fallback (colors unverified)')
 else:
  if len(colors)!=50:raise ValueError('Expected 50 level colors')
 colors=[int(s[3:9],16) for s in colors]
 lines=['/* ORIGINAL RUN 1 LEVEL DATA */',
        '/* Generated directly from supplied Run.swf AS3 advLevels array. */',
        '/* NOT procedural levels.  Data is kept in original 50-level order. */',
        '#include "original_maps.h"','#include <stddef.h>','',
        'const uint16_t run_original_words[] = {']
 for i in range(0,len(raw_words),12):lines.append('    '+', '.join(f'0x{w:04X}' for w in raw_words[i:i+12])+',')
 lines += ['};','',
           'const RunOriginalLevel run_original_levels[RUN_ORIGINAL_LEVEL_COUNT] = {']
 for i,(off,n,col) in enumerate(zip(offsets,lengths,colors)):
  tutorial=('"Use the arrow keys to move and space to jump."' if i==0 else '"Try touching one of the walls."' if i==1 else 'NULL')
  lines.append(f'    {{ {off:4d}, {n:3d}, 0x{col:06X}, {tutorial} }}, /* Level {i+1:02d} */')
 lines += ['};','',f'const uint32_t run_original_total_segments = {len(raw_words)}u;', '']
 target.write_text('\n'.join(lines))
 data={'source_sha256':hashlib.sha256(__import__('zipfile').ZipFile(args.source).read('Run.swf') if __import__('zipfile').is_zipfile(args.source) else Path(args.source).read_bytes()).hexdigest(),
       'level_count':50,'total_segments':len(raw_words),
       'levels':[{'level':i+1,'segments':n,'offset':off,'color_rgb':f'#{col:06X}', 'first_words':[f'{w:04X}' for w in raw_words[off:off+5]]} for i,(off,n,col) in enumerate(zip(offsets,lengths,colors))],
       'warnings':warnings}
 (root/'original_map_manifest.json').write_text(json.dumps(data,indent=2)+'\n')
 print(f'Extracted {len(maps)} ORIGINAL Adventure levels ({len(raw_words)} tunnel segments).')
 print(f'Source file SHA256: {data["source_sha256"]}')
 for warn in warnings:print('Note:',warn)
 print('Generated:',target,'and original_map_manifest.json')

if __name__=='__main__':main()
