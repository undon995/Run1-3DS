import zlib,struct,zipfile,collections,os
src=os.environ.get('RUN_SWF', 'Run.swf')
if zipfile.is_zipfile(src):
 b=zipfile.ZipFile(src).read('Run.swf')
else:
 b=open(src,'rb').read()
if b[:3]==b'CWS':
 d=b[:8]+zlib.decompress(b[8:])
elif b[:3]==b'FWS':
 d=b
else:
 raise ValueError('Expected original FWS/CWS Flash game')
p=8+((5+4*(d[8]>>3)+7)//8)+4
abc=[]; tags=[]
while p+2<len(d):
 h=struct.unpack_from('<H',d,p)[0];p+=2;c=h>>6; sz=h&63
 if sz==63:sz=struct.unpack_from('<I',d,p)[0];p+=4
 body=d[p:p+sz];p+=sz; tags.append((c,sz,body))
 if c==82: abc.append(body[body.find(b'\x00',4)+1:])
 if c==0:break
class Reader:
 def __init__(self,b): self.b=b;self.i=0
 def u8(self):o=self.b[self.i];self.i+=1;return o
 def u16(self):o=struct.unpack_from('<H',self.b,self.i)[0];self.i+=2;return o
 def u30(self):
  o=0
  for j in range(5):
   ch=self.u8();o|=(ch&127)<<(j*7)
   if ch<128:return o
  return o
 def read(self,n):o=self.b[self.i:self.i+n];self.i+=n;return o
 def double(self): return struct.unpack('<d',self.read(8))[0]

def read_constants(ab):
 r=Reader(ab);_minor,_major=r.u16(),r.u16();ints=[None]+[r.u30() for _ in range(r.u30()-1)];uints=[None]+[r.u30() for _ in range(r.u30()-1)];dbls=[None]+[r.double() for _ in range(r.u30()-1)];
 strings=[None]+[r.read(r.u30()).decode('utf8','replace') for _ in range(r.u30()-1)]
 return r,ints,uints,dbls,strings
if __name__=='__main__':
 for k,ab in enumerate(abc):
  print('ABC',k,len(ab));r,ints,uints,dbls,ss=read_constants(ab)
  print('int',len(ints),'uint',len(uints),'double',len(dbls),'strings',len(ss),'r at',r.i)
  open(f'/mnt/data/run_abc{k}_strings.txt','w').write('\n'.join('%04d %r'%(i,s) for i,s in enumerate(ss)))
  print('longest strings', sorted([(len(s or ''),i,(s or '')[:180]) for i,s in enumerate(ss)],reverse=True)[:30]);print('most relevant:',[(i,s[:200]) for i,s in enumerate(ss) if s and any(w in s.lower() for w in ('level','world','stage','map','course','jump','infinite','tunnel','gravity','tile','wall','platform','track','floor'))][:100]);print('int examples',ints[:30], 'double',dbls[:30])
