from parse_run_abc import *

KIND={0:'slot',1:'method',2:'getter',3:'setter',4:'class',5:'function',6:'const'}

class ABC:
 def __init__(self,blob):
  self.r,self.ints,self.uints,self.doubles,self.strings=read_constants(blob);r=self.r
  self.namespaces=[None]
  for x in range(r.u30()-1):self.namespaces.append((r.u8(),r.u30()))
  self.ns_sets=[None]
  for x in range(r.u30()-1):self.ns_sets.append([r.u30() for _ in range(r.u30())])
  self.names=[None]
  for x in range(r.u30()-1):
   k=r.u8()
   if k in (7,13):v=(r.u30(),r.u30())
   elif k in (15,16):v=(r.u30(),)
   elif k in (17,18):v=()
   elif k in (9,14):v=(r.u30(),r.u30())
   elif k in (27,28):v=(r.u30(),)
   elif k==29:v=(r.u30(),[r.u30() for _ in range(r.u30())])
   else:raise Exception(('multiname kind',k,r.i))
   self.names.append((k,v))
  self.methods=[]
  for x in range(r.u30()):
   count=r.u30();rt=r.u30();param=[r.u30() for _ in range(count)];nm=r.u30();flags=r.u8();opt=[];param_names=[]
   if flags&8: opt=[(r.u30(),r.u8()) for _ in range(r.u30())]
   if flags&128:param_names=[r.u30() for _ in range(count)]
   self.methods.append(dict(returntype=rt,params=param,name=nm,flags=flags,opts=opt,param_names=param_names,index=x))
  self.metadata=[]
  for x in range(r.u30()):
   n=r.u30();items=[(r.u30(),r.u30()) for _ in range(r.u30())];self.metadata.append((n,items))
  self.instances=[]
  for x in range(r.u30()):
   name=r.u30();supername=r.u30();flags=r.u8();protect=r.u30() if flags&8 else 0;interfaces=[r.u30() for _ in range(r.u30())];iinit=r.u30();traits=self.traits()
   self.instances.append(dict(name=name,super=supername,flags=flags,protect=protect,interfaces=interfaces,iinit=iinit,traits=traits))
  self.classes=[]
  for x in range(len(self.instances)):self.classes.append(dict(cinit=r.u30(),traits=self.traits()))
  self.scripts=[]
  for x in range(r.u30()):self.scripts.append(dict(init=r.u30(),traits=self.traits()))
  self.bodies=[]
  for x in range(r.u30()):
   method=r.u30();maxstack=r.u30();local=r.u30();init_scope=r.u30();max_scope=r.u30();code=r.read(r.u30()); exceptions=[]
   for y in range(r.u30()):exceptions.append(tuple(r.u30() for _ in range(5)))
   traits=self.traits();self.bodies.append(dict(method=method,maxstack=maxstack,local=local,init_scope=init_scope,max_scope=max_scope,code=code,exceptions=exceptions,traits=traits))
  assert r.i==len(blob),(r.i,len(blob))
  self.method_to_context={}
  for i,inst in enumerate(self.instances):
   classname=self.name(inst['name']);self.method_to_context[inst['iinit']]=classname+'::ctor'
   for t in inst['traits']:
    if t['kind'] in (1,2,3,5):self.method_to_context[t['method']]=classname+'::'+self.name(t['name'])
  for i,c in enumerate(self.classes):
   classname=self.name(self.instances[i]['name']);self.method_to_context[c['cinit']]=classname+'::static ctor'
   for t in c['traits']:
    if t['kind'] in (1,2,3,5):self.method_to_context[t['method']]=classname+'::static '+self.name(t['name'])
  for i,sc in enumerate(self.scripts):
   self.method_to_context[sc['init']]='SCRIPT '+str(i)+' init'
   for t in sc['traits']:
    if t['kind'] in (1,2,3,5):self.method_to_context[t['method']]='SCRIPT '+str(i)+' '+self.name(t['name'])
 def name(self,n):
  if not n:return '*'
  kind,v=self.names[n]
  if kind in (7,13):
   ns,name=v; nsid=self.namespaces[ns][1];nss=self.strings[nsid] or '' ; return (nss+':' if nss else '')+(self.strings[name] or '')
  if kind in (9,14,15,16):return self.strings[v[0]] or '*'
  return str((kind,v))
 def traits(self):
  r=self.r;out=[]
  for i in range(r.u30()):
   name=r.u30();kattr=r.u8();k=kattr&15;d={'name':name,'kind':k}
   if k in (0,6):
    d.update(slot=r.u30(),typename=r.u30());d['vindex']=r.u30()
    if d['vindex']!=0:d['vkind']=r.u8()
   elif k in (1,2,3):d.update(dispid=r.u30(),method=r.u30())
   elif k==4:d.update(slot=r.u30(),classindex=r.u30())
   elif k==5:d.update(slot=r.u30(),method=r.u30())
   else:raise Exception(('trait kind',k,r.i))
   if kattr&0x40: d['metadata']=[r.u30() for _ in range(r.u30())]
   out.append(d)
  return out

if __name__=='__main__':
 for k,ab in enumerate(abc):
  a=ABC(ab)
  print('\nABC',k,'classes',len(a.classes),'methods',len(a.methods),'bodies',len(a.bodies),'scripts',len(a.scripts),'classes names', [a.name(inst['name']) for inst in a.instances][:70])
  print('Methods matching level',[(j,name) for j,name in a.method_to_context.items() if any(w in name.lower() for w in ('level','tile','map','tor','load','update'))][:90])
  for body in a.bodies:
   code=body['code']; found=[]
   for off,c in enumerate(code):
    if c==0x2C:
     r=Reader(code);r.i=off+1
     try:
      n=r.u30();
      if n<len(a.strings) and a.strings[n] and a.strings[n].startswith('0x') and len(a.strings[n])>30:found.append(n)
     except:pass
   if found:print('Method',body['method'],a.method_to_context.get(body['method']), 'maprefs',found, 'length',len(code))
