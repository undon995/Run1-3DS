#include "game.h"
#include "original_maps.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

/* Independent reference: reconstruct the source SWF's 6x6 perimeter grid
   from each 4-digit hex group, then compare its edge cells to C decoder. */
static unsigned expected_tile(unsigned short word, int face, int lane) {
    unsigned bits[6][6] = {{0}};
    unsigned n0=(word>>12)&15u, n1=(word>>8)&15u;
    unsigned n2=(word>>4)&15u, n3=word&15u;
    for (int t=0;t<4;t++) {
        bits[4-t][5] = (n0 >> t)&1u; /* right */
        bits[5][1+t] = (n1 >> t)&1u; /* floor */
        bits[1+t][0] = (n2 >> t)&1u; /* left */
        bits[0][4-t] = (n3 >> t)&1u; /* top */
    }
    switch(face) {
        case 0: return bits[5][1+lane];
        case 1: return bits[4-lane][5];
        case 2: return bits[0][4-lane];
        default:return bits[1+lane][0];
    }
}

static void test_flash_wall_order(void) {
    RunGame g;
    run_init(&g);
    /* Level 2's first original hex word is 0F00: only bottom 4 tiles.
       The earlier port mistakenly drew this as a LEFT wall. */
    run_start_level(&g, 1);
    assert(run_original_word_at(1,0)==0x0F00u);
    for (int lane=0;lane<4;lane++) {
        assert(run_tile_at(&g,0,0,lane)==1);
        assert(run_tile_at(&g,0,1,lane)==0);
        assert(run_tile_at(&g,0,2,lane)==0);
        assert(run_tile_at(&g,0,3,lane)==0);
    }
}

static void test_original_levels(void) {
    RunGame g;
    run_init(&g);
    assert(g.mode == RUN_TITLE);
    assert(g.unlocked_level == 0);
    assert(run_original_total_segments == 3276);
    assert(run_original_levels[0].length == 49);
    assert(run_original_levels[1].length == 57);
    assert(run_original_levels[49].length == 64);
    /* Per-level colors are preserved from the original SWF, not guessed. */
    assert(run_original_levels[0].color_rgb == 0x4F7BFFu);
    assert(run_original_levels[49].color_rgb == 0xFF0000u);
    assert(run_original_word_at(0,0) == 0xFFFFu);
    assert(run_original_word_at(1,0) == 0x0F00u);
    assert(run_original_word_at(49,0) == 0x0400u);
    assert(run_original_word_at(0,-1) == 0);
    assert(run_original_word_at(50,0) == 0);
    assert(strstr(run_original_levels[0].tutorial,"arrow keys") != NULL);
    int sum = 0;
    for (int level=0;level<RUN_ADVENTURE_LEVELS;level++) {
        run_start_level(&g, level);
        assert(g.length == run_original_levels[level].length);
        assert(g.length >= 20 && g.length <= RUN_SEGMENTS);
        assert(g.mode == RUN_PLAYING);
        sum += g.length;
        for (int s=0;s<g.length;s++) {
            unsigned short word=run_original_word_at(level,s);
            for (int f=0;f<4;f++)for(int l=0;l<4;l++)
                assert(run_tile_at(&g,s,f,l)==(int)expected_tile(word,f,l));
        }
        assert(!run_tile_at(&g,g.length,0,0));
        assert(!run_tile_at(&g,0,4,0));
        assert(!run_tile_at(&g,0,0,4));
    }
    assert(sum == 3276);
}

static void test_rotation(void) {
    RunGame g;
    run_init(&g);
    run_start_level(&g,0);
    g.x = 1.40f;
    g.lateral_velocity = 3.0f;
    g.z = 0.0f;
    g.height = 2.0f;
    run_update(&g,1.0f/60.0f,1,0);
    assert(g.face==1);
    run_restart(&g);
    assert(g.mode==RUN_PLAYING && g.z < 1.0f);
    assert(g.deaths==0);
}

static void test_progression(void) {
    RunGame g;
    run_init(&g);
    run_start_level(&g,0);
    /* Temporary all-solid geometry ONLY inside this unit test to drive
       the clear-level logic, never saved to the build's original level data. */
    memset(g.tiles,1,sizeof g.tiles);
    for (int i=0;i<1400 && g.mode==RUN_PLAYING;i++)run_update(&g,1.0f/60,0,0);
    assert(g.mode==RUN_FINISHED);
    assert(g.unlocked_level==1);
    run_start_level(&g,RUN_ADVENTURE_LEVELS-1);
    memset(g.tiles,1,sizeof g.tiles);
    for (int i=0;i<1400 && g.mode==RUN_PLAYING;i++)run_update(&g,1.0f/60,0,0);
    assert(g.mode==RUN_FINISHED && g.finished_adventure==1);
}

static void test_no_fake_infinite(void) {
    RunGame g;
    run_init(&g);
    RunMode mode=g.mode;
    run_start_infinite(&g);
    assert(g.mode==mode);
    assert(g.kind==RUN_ADVENTURE);
}

static void test_saving(void) {
    RunGame g;
    run_init(&g);
    g.unlocked_level=24;
    g.total_deaths=173;
    g.best_infinite=0;
    g.theme=0;
    g.dirty=1;
    const char *path="/tmp/run3ds_original_save.bin";
    assert(run_save_write(&g,path));
    RunGame loaded;
    run_init(&loaded);
    assert(run_save_read(&loaded,path));
    assert(loaded.unlocked_level==24);
    assert(loaded.total_deaths==173);
    FILE *f=fopen(path,"r+b");
    assert(f);
    assert(fseek(f,9,SEEK_SET)==0);
    fputc(0xCC,f);
    fclose(f);
    assert(!run_save_read(&loaded,path));
    remove(path);
}

static void test_music_settings_saving(void) {
    const char *path="/tmp/run3ds_music_settings.bin";
    int music=1;
    assert(!run_settings_save_read(&music,path));
    assert(music==1); /* missing settings file does not change default */
    assert(run_settings_save_write(0,path));
    assert(run_settings_save_read(&music,path) && music==0);
    assert(run_settings_save_write(1,path));
    assert(run_settings_save_read(&music,path) && music==1);
    FILE *f=fopen(path,"r+b");
    assert(f);
    assert(fseek(f,8,SEEK_SET)==0);
    fputc(9,f); /* invalid option and checksum */
    fclose(f);
    music=1;
    assert(!run_settings_save_read(&music,path));
    assert(music==1);
    remove(path);
}

int main(void) {
    test_flash_wall_order();
    test_original_levels();
    test_rotation();
    test_progression();
    test_no_fake_infinite();
    test_saving();
    test_music_settings_saving();
    puts("PASS: SWF perimeter parser wall order, all 50 original maps (3276 exact rows), progression, saves, and Music On/Off preferences");
    return 0;
}
