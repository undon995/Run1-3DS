#ifndef RUN_MUSIC_H
#define RUN_MUSIC_H

/* Genuine music extracted from the user-supplied Run.swf. */
void run_music_init(int start_enabled);
void run_music_set_enabled(int enabled);
void run_music_update(void);
void run_music_exit(void);
const char *run_music_status_text(void);

#endif
