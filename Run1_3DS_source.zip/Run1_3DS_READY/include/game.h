#ifndef RUN3DS_GAME_H
#define RUN3DS_GAME_H

#include <stdint.h>

#define RUN_SEGMENTS 160
#define RUN_LANES 4
#define RUN_FACES 4
#define RUN_ADVENTURE_LEVELS 50

/* Original Adventure layouts extracted from user-supplied Run.swf.
   Current engine physics and rendering still need fidelity tuning. */
typedef enum {
    RUN_TITLE, RUN_LEVEL_SELECT, RUN_OPTIONS,
    RUN_PLAYING, RUN_PAUSED, RUN_FINISHED, RUN_GAME_OVER, RUN_SETTINGS
} RunMode;

typedef enum { RUN_ADVENTURE = 0, RUN_INFINITE = 1 } RunKind;

typedef struct {
    RunMode mode;
    RunKind kind;
    int level;                 /* 0-based adventure level */
    int selected_level;
    int unlocked_level;        /* highest unlocked 0-based level */
    int face;                  /* floor=0, right=1, top=2, left=3 */
    int deaths;
    int total_deaths;
    int best_infinite;
    int theme;
    int finished_adventure;
    int dirty;
    int length;
    float z, x, height, vertical_velocity;
    float lateral_velocity, rotation, time_elapsed, death_flash;
    float coyote, jump_buffer;
    uint8_t tiles[RUN_SEGMENTS][RUN_FACES][RUN_LANES];
    int32_t segment_tag[RUN_SEGMENTS];
} RunGame;

void run_init(RunGame *g);
void run_start_level(RunGame *g, int level);
void run_start_infinite(RunGame *g); /* disabled until original algorithm is ported */
void run_restart(RunGame *g);
void run_update(RunGame *g, float dt, float movement, int jump_pressed);
void run_prepare_visible(RunGame *g);
int run_tile_at(const RunGame *g, int segment, int face, int lane);
uint16_t run_original_word_at(int level, int segment);
int run_current_lane(const RunGame *g);
int run_infinite_difficulty(const RunGame *g);

/* Save file is intentionally independent of the 3DS SDK for testing. */
int run_save_write(const RunGame *g, const char *path);
int run_save_read(RunGame *g, const char *path);
/* Independent settings file; does not change or invalidate legacy save.dat. */
int run_settings_save_read(int *music_on, const char *path);
int run_settings_save_write(int music_on, const char *path);
#endif
