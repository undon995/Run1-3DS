#ifndef RUN_ORIGINAL_MAPS_H
#define RUN_ORIGINAL_MAPS_H
#include <stdint.h>
#define RUN_ORIGINAL_LEVEL_COUNT 50
typedef struct { uint16_t offset, length; uint32_t color_rgb; const char *tutorial; } RunOriginalLevel;
extern const uint16_t run_original_words[];
extern const RunOriginalLevel run_original_levels[RUN_ORIGINAL_LEVEL_COUNT];
extern const uint32_t run_original_total_segments;
#endif
