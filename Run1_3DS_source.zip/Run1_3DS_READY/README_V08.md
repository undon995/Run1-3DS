# Run 1 3DS V0.8 — Title ID + original music

**Addresses both reported issues:**

1. Run no longer uses the same Title ID as the earlier Impossible Game beta. Run has `UniqueId: 0xFF7A6` (full Application Title ID `000400000FF7A600`), product code `CTR-P-RN3D`.
2. The native 3DS game now **actually plays** the **embedded original Run.swf music** (SWF sound tag 643, ~122 seconds). This is not a remix or AI-generated track. The PCM file is already included, so **you do not need FFmpeg or the SWF to build this private test**.
3. Audio is played through **libctru NDSP**, using 4 streaming buffers of 4096 samples (32 KiB linear memory), on both title screen and during gameplay. If NDSP cannot initialize, the game runs silently instead of crashing and shows `MUSIC DSP UNAVAILABLE` on the lower title screen.
4. The SWF-derived alien sprite frames, original level strings (50), corrected tunnel geometry, original title menu, your supplied HOME Menu icon and banner all remain.

## Build the full project (recommended)

Download `Run1_3DS_V08_TitleID_OriginalMusic_FULL.zip` to `C:\Users\natha\Downloads`, then in devkitPro MSYS2:

```bash
cd /c/Users/natha/Downloads
unzip -o Run1_3DS_V08_TitleID_OriginalMusic_FULL.zip
cd Run1_3DS_V08_TITLE_ID_AND_ORIGINAL_MUSIC
bash BUILD_CIA_MSYS2.sh
```

Build output: **`Run1_2008_3DS_V08_ORIGINAL_MUSIC.cia`**.

The script looks for `bannertool.exe` and `makerom.exe` in the old V0.3 folder. If it cannot find them, copy those two executables to this new folder (or add their folder to PATH). **The ZIP does not contain them**.

## Test the CIA in Azahar

Use Azahar → File → Install CIA, choose `Run1_2008_3DS_V08_ORIGINAL_MUSIC.cia`, and start it. It should install as a **new app** rather than replacing Impossible Game. The song should begin on Run's title screen, and loop while you play. If silent, check the bottom of the title screen for the status string; emulator/console DSP support may be required.

**If Impossible Game was already replaced by an older Run CIA, reinstall your Impossible Game CIA separately to restore it.** This patch does not restore an overwritten install by itself.

## Limitations

The audio content is authentic, but its original Flash timing, transitions, and exact loop point have not been matched to the Flash game's sound scheduler. The core 3DS port is still not a complete 1:1 recreation: movement, camera, collision, Infinite Mode, Edit Mode and red/yellow/green indicators need additional verification or work. This package was checked for script syntax, source consistency and desktop tests, but it **was not compiled with devkitARM or tested in Azahar here**.

The extracted audio comes from *your* uploaded SWF. It is included for private testing, not a grant of permission for public redistribution.
