RUN 1 3DS - CIA TEST BUILD KIT

You already have devkitPro MSYS2 and Azahar on Windows.

1. Unzip the project anywhere under Downloads, in a directory without spaces.
2. Make sure makerom.exe and bannertool.exe are either on PATH or copied into the extracted folder.
3. Open devkitPro MSYS2, cd to the extracted Run1_Original_Maps_3DS_CIA_Kit directory.
4. Run: bash BUILD_CIA_MSYS2.sh
5. If successful, load Run1_2008_3DS_TEST.cia in Azahar using File > Install CIA (or the current equivalent menu). Launch the installed title from the emulator's game list.

Troubleshooting: If an older makerom build does not support the RSF field DirectSdmcWrite, remove only that field from project.rsf and try again (save functionality may be limited). If makerom says invalid exheader, share the full error log.

STATUS: This is a build kit, NOT a precompiled CIA. The devkitARM compiler and Windows makerom/bannertool are unavailable inside this assistant's Linux runtime, so CIA output cannot be confirmed here.

AUTHENTICITY: The current homebrew engine contains the 50 original encoded map layouts derived from your supplied Run.swf. Visuals, animations, physics, and infinite mode are still recreation/incomplete. The CIA is intended for local testing, not a claim of completed original Run port.
